/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          bg: '#0a0f18',
          card: '#111827',
          border: '#1f2937',
          green: '#00ff88',
          yellow: '#fbbf24',
          red: '#f87171',
          blue: '#60a5fa',
          muted: '#6b7280',
        }
      },
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
