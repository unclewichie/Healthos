// pages/api/strava/data.js
function parseCookies(req) {
  const raw = req.headers.cookie || '';
  return Object.fromEntries(raw.split(';').map(c => {
    const [k, ...v] = c.trim().split('=');
    return [k, v.join('=')];
  }));
}

async function refreshStravaToken(refreshToken) {
  const res = await fetch('https://www.strava.com/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      client_id: process.env.STRAVA_CLIENT_ID,
      client_secret: process.env.STRAVA_CLIENT_SECRET,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  });
  return res.json();
}

export default async function handler(req, res) {
  const cookies = parseCookies(req);
  let token = cookies.strava_access;

  if (!token && cookies.strava_refresh) {
    // Try to refresh
    const refreshed = await refreshStravaToken(cookies.strava_refresh);
    if (refreshed.access_token) {
      token = refreshed.access_token;
      res.setHeader('Set-Cookie',
        `strava_access=${token}; HttpOnly; Path=/; Max-Age=21600; SameSite=Lax`
      );
    }
  }

  if (!token) {
    return res.status(401).json({ error: 'not_connected' });
  }

  try {
    // Get athlete stats + recent activities
    const athleteRes = await fetch('https://www.strava.com/api/v3/athlete', {
      headers: { Authorization: `Bearer ${token}` },
    });
    const athlete = await athleteRes.json();

    const activitiesRes = await fetch(
      'https://www.strava.com/api/v3/athlete/activities?per_page=20',
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const activities = await activitiesRes.json();

    const statsRes = await fetch(
      `https://www.strava.com/api/v3/athletes/${athlete.id}/stats`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const stats = await statsRes.json();

    // Process recent activities
    const recent = (activities || []).slice(0, 10).map(a => ({
      date: a.start_date_local?.split('T')[0],
      name: a.name,
      type: a.type,
      distance: parseFloat((a.distance / 1609.34).toFixed(2)), // miles
      duration: Math.round(a.moving_time / 60), // minutes
      elevation: Math.round(a.total_elevation_gain * 3.28084), // feet
      avgHR: a.average_heartrate ? Math.round(a.average_heartrate) : null,
      maxHR: a.max_heartrate ? Math.round(a.max_heartrate) : null,
      avgPace: a.type === 'Run' && a.moving_time && a.distance
        ? `${Math.floor((a.moving_time / 60) / (a.distance / 1609.34))}:${String(Math.round(((a.moving_time / 60) / (a.distance / 1609.34) % 1) * 60)).padStart(2, '0')}`
        : null,
      avgWatts: a.average_watts ? Math.round(a.average_watts) : null,
      kudos: a.kudos_count,
    }));

    // Weekly summary (last 4 weeks)
    const now = Date.now();
    const weekMs = 7 * 24 * 3600 * 1000;
    const weeklyRuns = [0, 1, 2, 3].map(w => {
      const weekActivities = (activities || []).filter(a => {
        const age = now - new Date(a.start_date).getTime();
        return age >= w * weekMs && age < (w + 1) * weekMs;
      });
      const runs = weekActivities.filter(a => a.type === 'Run');
      const rides = weekActivities.filter(a => a.type === 'Ride' || a.type === 'VirtualRide');
      return {
        week: w === 0 ? 'This week' : `${w}w ago`,
        runMiles: parseFloat(runs.reduce((s, a) => s + a.distance / 1609.34, 0).toFixed(1)),
        runCount: runs.length,
        rideMins: Math.round(rides.reduce((s, a) => s + a.moving_time / 60, 0)),
        rideCount: rides.length,
      };
    });

    // VO2max from athlete profile
    const vo2max = athlete.ftp
      ? Math.round(athlete.ftp / 3.5) // rough estimate from FTP
      : null;

    res.json({
      connected: true,
      athlete: {
        name: `${athlete.firstname} ${athlete.lastname}`,
        ftp: athlete.ftp || null,
        vo2max,
      },
      stats: {
        ytdRuns: stats.ytd_run_totals?.count || 0,
        ytdRunMiles: parseFloat(((stats.ytd_run_totals?.distance || 0) / 1609.34).toFixed(1)),
        ytdRides: stats.ytd_ride_totals?.count || 0,
        ytdRideMiles: parseFloat(((stats.ytd_ride_totals?.distance || 0) / 1609.34).toFixed(1)),
        allTimeRuns: stats.all_run_totals?.count || 0,
      },
      recent,
      weekly: weeklyRuns,
    });
  } catch (err) {
    console.error('Strava data error:', err);
    res.status(500).json({ error: 'fetch_failed', message: err.message });
  }
}
