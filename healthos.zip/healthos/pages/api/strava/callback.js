// pages/api/strava/callback.js
export default async function handler(req, res) {
  const { code } = req.query;
  if (!code) return res.redirect('/?error=strava_denied');

  try {
    const tokenRes = await fetch('https://www.strava.com/oauth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_id: process.env.STRAVA_CLIENT_ID,
        client_secret: process.env.STRAVA_CLIENT_SECRET,
        code,
        grant_type: 'authorization_code',
      }),
    });

    const tokens = await tokenRes.json();
    if (!tokens.access_token) throw new Error('No access token');

    res.setHeader('Set-Cookie', [
      `strava_access=${tokens.access_token}; HttpOnly; Path=/; Max-Age=21600; SameSite=Lax`,
      `strava_refresh=${tokens.refresh_token}; HttpOnly; Path=/; Max-Age=2592000; SameSite=Lax`,
      `strava_athlete=${encodeURIComponent(JSON.stringify({ id: tokens.athlete?.id, name: `${tokens.athlete?.firstname} ${tokens.athlete?.lastname}` }))}; Path=/; Max-Age=2592000; SameSite=Lax`,
    ]);

    res.redirect('/?connected=strava');
  } catch (err) {
    console.error('Strava auth error:', err);
    res.redirect('/?error=strava_auth_failed');
  }
}
