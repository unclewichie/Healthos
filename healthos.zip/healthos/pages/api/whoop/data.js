// pages/api/whoop/data.js
async function whoopFetch(path, token) {
  const res = await fetch(`https://api.prod.whoop.com/developer/v2${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(`WHOOP ${path} failed: ${res.status}`);
  return res.json();
}

function parseCookies(req) {
  const raw = req.headers.cookie || '';
  return Object.fromEntries(raw.split(';').map(c => {
    const [k, ...v] = c.trim().split('=');
    return [k, v.join('=')];
  }));
}

export default async function handler(req, res) {
  const cookies = parseCookies(req);
  const token = cookies.whoop_access;

  if (!token) {
    return res.status(401).json({ error: 'not_connected', message: 'WHOOP not connected' });
  }

  try {
    const [recovery, sleep, workouts, cycles, profile] = await Promise.all([
      whoopFetch('/recovery?limit=7', token),
      whoopFetch('/activity/sleep?limit=7', token),
      whoopFetch('/activity/workout?limit=10', token),
      whoopFetch('/cycle?limit=7', token),
      whoopFetch('/user/profile/basic', token),
    ]);

    // Latest recovery
    const latestRecovery = recovery.records?.[0];
    const latestSleep = sleep.records?.[0];
    const latestCycle = cycles.records?.[0];

    // Build 7-day history
    const history = (recovery.records || []).map((r, i) => ({
      date: r.created_at?.split('T')[0],
      recovery: Math.round(r.score?.recovery_score ?? 0),
      hrv: Math.round(r.score?.hrv_rmssd_milli ?? 0),
      rhr: Math.round(r.score?.resting_heart_rate ?? 0),
      sleepPerf: Math.round(sleep.records?.[i]?.score?.sleep_performance_percentage ?? 0),
      strain: parseFloat(cycles.records?.[i]?.score?.strain?.toFixed(1) ?? 0),
    }));

    // Workout summary
    const recentWorkouts = (workouts.records || []).slice(0, 5).map(w => ({
      date: w.start?.split('T')[0],
      sport: w.sport_id,
      strain: parseFloat(w.score?.strain?.toFixed(1) ?? 0),
      duration: Math.round((new Date(w.end) - new Date(w.start)) / 60000),
      avgHR: Math.round(w.score?.average_heart_rate ?? 0),
      maxHR: Math.round(w.score?.max_heart_rate ?? 0),
      calories: Math.round(w.score?.kilojoule * 0.239 ?? 0),
      zone2mins: Math.round(w.score?.zone_duration?.zone_two_milli / 60000 ?? 0),
    }));

    const data = {
      connected: true,
      profile: {
        name: `${profile.first_name} ${profile.last_name}`,
        email: profile.email,
      },
      today: {
        recovery: Math.round(latestRecovery?.score?.recovery_score ?? 0),
        hrv: Math.round(latestRecovery?.score?.hrv_rmssd_milli ?? 0),
        rhr: Math.round(latestRecovery?.score?.resting_heart_rate ?? 0),
        strain: parseFloat(latestCycle?.score?.strain?.toFixed(1) ?? 0),
        sleepHours: parseFloat((latestSleep?.score?.stage_summary?.total_in_bed_time_milli / 3600000)?.toFixed(1) ?? 0),
        sleepPerf: Math.round(latestSleep?.score?.sleep_performance_percentage ?? 0),
        remMins: Math.round(latestSleep?.score?.stage_summary?.total_rem_sleep_time_milli / 60000 ?? 0),
        deepMins: Math.round(latestSleep?.score?.stage_summary?.total_slow_wave_sleep_time_milli / 60000 ?? 0),
        respiratoryRate: parseFloat(latestSleep?.score?.respiratory_rate?.toFixed(1) ?? 0),
      },
      history,
      workouts: recentWorkouts,
      // Zone 2 calculation from last 7 workouts
      zone2Percent: (() => {
        const totalMins = recentWorkouts.reduce((a, w) => a + w.duration, 0);
        const z2Mins = recentWorkouts.reduce((a, w) => a + w.zone2mins, 0);
        return totalMins > 0 ? Math.round((z2Mins / totalMins) * 100) : 0;
      })(),
    };

    res.json(data);
  } catch (err) {
    console.error('WHOOP data error:', err);
    // Token might be expired - clear it
    if (err.message.includes('401')) {
      res.setHeader('Set-Cookie', 'whoop_access=; HttpOnly; Path=/; Max-Age=0');
      return res.status(401).json({ error: 'token_expired' });
    }
    res.status(500).json({ error: 'fetch_failed', message: err.message });
  }
}
