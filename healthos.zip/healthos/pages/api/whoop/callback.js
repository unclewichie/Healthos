// pages/api/whoop/callback.js
export default async function handler(req, res) {
  const { code } = req.query;
  if (!code) return res.redirect('/?error=whoop_denied');

  try {
    const tokenRes = await fetch('https://api.prod.whoop.com/oauth/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        client_id: process.env.WHOOP_CLIENT_ID,
        client_secret: process.env.WHOOP_CLIENT_SECRET,
        redirect_uri: process.env.WHOOP_REDIRECT_URI,
      }),
    });

    const tokens = await tokenRes.json();
    if (!tokens.access_token) throw new Error('No access token');

    // Store tokens in cookies (httpOnly, secure)
    res.setHeader('Set-Cookie', [
      `whoop_access=${tokens.access_token}; HttpOnly; Path=/; Max-Age=3600; SameSite=Lax`,
      `whoop_refresh=${tokens.refresh_token}; HttpOnly; Path=/; Max-Age=2592000; SameSite=Lax`,
    ]);

    res.redirect('/?connected=whoop');
  } catch (err) {
    console.error('WHOOP auth error:', err);
    res.redirect('/?error=whoop_auth_failed');
  }
}
