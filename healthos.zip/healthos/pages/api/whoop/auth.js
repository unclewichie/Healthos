// pages/api/whoop/auth.js
// Step 1: Redirect user to WHOOP login
export default function handler(req, res) {
  const params = new URLSearchParams({
    client_id: process.env.WHOOP_CLIENT_ID,
    redirect_uri: process.env.WHOOP_REDIRECT_URI,
    response_type: 'code',
    scope: 'read:recovery read:sleep read:workout read:cycle read:profile read:body_measurement',
  });
  res.redirect(`https://api.prod.whoop.com/oauth/oauth2/auth?${params}`);
}
