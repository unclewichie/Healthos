// pages/api/nutrition/upload.js
export const config = { api: { bodyParser: { sizeLimit: '2mb' } } };

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  try {
    const { csvData } = req.body;
    if (!csvData) return res.status(400).json({ error: 'No CSV data' });

    // Parse MFP CSV export format
    const lines = csvData.split('\n').filter(l => l.trim());
    const results = [];
    let currentDate = null;
    let dayData = null;

    for (const line of lines) {
      const cols = line.split(',').map(c => c.replace(/"/g, '').trim());

      // MFP export has date headers like "2024-03-01"
      if (cols[0].match(/^\d{4}-\d{2}-\d{2}$/)) {
        if (dayData) results.push(dayData);
        currentDate = cols[0];
        dayData = { date: currentDate, calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, sodium: 0, meals: [] };
      } else if (dayData && cols[0] && cols[0] !== 'Meal' && cols[0] !== 'Totals' && cols[0] !== 'Daily Totals') {
        // Food entry row
        const entry = {
          meal: cols[0],
          food: cols[1],
          calories: parseInt(cols[2]) || 0,
          carbs: parseInt(cols[3]) || 0,
          fat: parseInt(cols[4]) || 0,
          protein: parseInt(cols[5]) || 0,
          sodium: parseInt(cols[6]) || 0,
          fiber: parseInt(cols[7]) || 0,
        };
        dayData.calories += entry.calories;
        dayData.protein += entry.protein;
        dayData.carbs += entry.carbs;
        dayData.fat += entry.fat;
        dayData.fiber += entry.fiber;
        dayData.sodium += entry.sodium;
        dayData.meals.push(entry);
      }
    }
    if (dayData) results.push(dayData);

    // Compute averages
    const avg = (key) => results.length
      ? Math.round(results.reduce((s, d) => s + d[key], 0) / results.length)
      : 0;

    const summary = {
      days: results.length,
      dateRange: results.length ? `${results[0].date} to ${results[results.length - 1].date}` : '',
      averages: {
        calories: avg('calories'),
        protein: avg('protein'),
        carbs: avg('carbs'),
        fat: avg('fat'),
        fiber: avg('fiber'),
        sodium: avg('sodium'),
      },
      dailyData: results,
    };

    res.json({ success: true, nutrition: summary });
  } catch (err) {
    console.error('Nutrition parse error:', err);
    res.status(500).json({ error: 'parse_failed', message: err.message });
  }
}
