// pages/index.js
import { useState, useEffect, useRef, useCallback } from 'react';
import Head from 'next/head';

// ── Utility helpers ──────────────────────────────────────────────
const recoveryColor = (v) => v >= 67 ? '#00ff88' : v >= 34 ? '#fbbf24' : '#f87171';
const recoveryLabel = (v) => v >= 67 ? 'Green' : v >= 34 ? 'Yellow' : 'Red';
const fmt = (v, d = 0) => v != null ? Number(v).toFixed(d) : '—';

function Ring({ value, max = 100, color, size = 80, stroke = 8, label, sub }) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (Math.min(value || 0, max) / max) * circ;
  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={size} height={size}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#1f2937" strokeWidth={stroke}/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke}
          strokeDasharray={circ} strokeDashoffset={offset}
          strokeLinecap="round" transform={`rotate(-90 ${size/2} ${size/2})`}
          style={{transition:'stroke-dashoffset 1s ease'}}/>
        <text x={size/2} y={size/2} textAnchor="middle" dominantBaseline="middle"
          fill={color} fontSize={size > 70 ? 18 : 13} fontWeight="700">{value ?? '—'}</text>
      </svg>
      <span className="text-xs text-gray-400">{label}</span>
      {sub && <span className="text-xs" style={{color}}>{sub}</span>}
    </div>
  );
}

function Card({ children, className = '', glow }) {
  return (
    <div className={`rounded-xl border border-gray-800 bg-gray-900 p-4 ${glow ? 'glow-' + glow : ''} ${className}`}>
      {children}
    </div>
  );
}

function Badge({ children, color = 'green' }) {
  const colors = {
    green: 'bg-green-900 text-green-300',
    yellow: 'bg-yellow-900 text-yellow-300',
    red: 'bg-red-900 text-red-300',
    blue: 'bg-blue-900 text-blue-300',
    gray: 'bg-gray-800 text-gray-400',
  };
  return <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${colors[color]}`}>{children}</span>;
}

// ── Bloodwork data ───────────────────────────────────────────────
const bloodworkData = [
  { name: 'LDL Cholesterol', mar25: 85, oct25: 95, feb26: 77, unit: 'mg/dL', target: '<70 (Lp(a) risk)', status: 'watch', trend: '↓' },
  { name: 'ApoB', mar25: '—', oct25: '—', feb26: 78, unit: 'mg/dL', target: '<70', status: 'watch', trend: '—' },
  { name: 'Lp(a)', mar25: '—', oct25: '—', feb26: 137, unit: 'nmol/L', target: '<75', status: 'critical', trend: '🚨' },
  { name: 'Total Cholesterol', mar25: 142, oct25: 155, feb26: 137, unit: 'mg/dL', target: '<200', status: 'good', trend: '↓' },
  { name: 'Triglycerides', mar25: 76, oct25: 77, feb26: 79, unit: 'mg/dL', target: '<100', status: 'good', trend: '→' },
  { name: 'HDL Cholesterol', mar25: 42, oct25: 45, feb26: 44, unit: 'mg/dL', target: '>40', status: 'good', trend: '→' },
  { name: 'hsCRP', mar25: 0.29, oct25: 0.31, feb26: 0.4, unit: 'mg/L', target: '<1.0', status: 'good', trend: '→' },
  { name: 'Homocysteine', mar25: 9.8, oct25: 9.9, feb26: 8.9, unit: 'umol/L', target: '<10', status: 'good', trend: '↓' },
  { name: 'HbA1c', mar25: 5.3, oct25: 5.3, feb26: 5.2, unit: '%', target: '<5.7', status: 'good', trend: '↓' },
  { name: 'Fasting Glucose', mar25: 99, oct25: 94, feb26: 98, unit: 'mg/dL', target: '70-99', status: 'good', trend: '→' },
  { name: 'Fasting Insulin', mar25: 7.3, oct25: 11.9, feb26: 8.3, unit: 'uIU/mL', target: '<8', status: 'watch', trend: '↓' },
  { name: 'Testosterone', mar25: 655, oct25: 633, feb26: 719, unit: 'ng/dL', target: '400-916', status: 'good', trend: '↑' },
  { name: 'Free Testosterone', mar25: 10.2, oct25: 9.8, feb26: 105.7, unit: 'pg/mL', target: '35-155', status: 'good', trend: '↑' },
  { name: 'Estradiol', mar25: 26.0, oct25: 20.3, feb26: 38, unit: 'pg/mL', target: '<42.6', status: 'watch', trend: '↑' },
  { name: 'DHEA-S', mar25: 177, oct25: 309, feb26: 292, unit: 'mcg/dL', target: '<279', status: 'watch', trend: '↓' },
  { name: 'Vitamin D', mar25: 65.3, oct25: 83.7, feb26: 58, unit: 'ng/mL', target: '60-80', status: 'watch', trend: '↓' },
  { name: 'Ferritin', mar25: 331, oct25: 285, feb26: 206, unit: 'ng/mL', target: '30-400', status: 'watch', trend: '↓' },
  { name: 'Vitamin B12', mar25: 549, oct25: 680, feb26: '—', unit: 'pg/mL', target: '400-1000', status: 'good', trend: '→' },
  { name: 'IGF-1', mar25: 171, oct25: 174, feb26: '—', unit: 'ng/mL', target: '74-255', status: 'good', trend: '→' },
  { name: 'TSH', mar25: 1.46, oct25: 2.44, feb26: 1.54, unit: 'uIU/mL', target: '0.45-4.5', status: 'good', trend: '→' },
  { name: 'Cortisol (AM)', mar25: 9.0, oct25: 13.4, feb26: 12.0, unit: 'ug/dL', target: '4-22', status: 'good', trend: '→' },
  { name: 'PSA', mar25: 0.5, oct25: 0.5, feb26: '—', unit: 'ng/mL', target: '<4.0', status: 'good', trend: '→' },
  { name: 'eGFR', mar25: 86, oct25: 85, feb26: 92, unit: 'mL/min', target: '>60', status: 'good', trend: '↑' },
  { name: 'Creatinine', mar25: 1.04, oct25: 1.05, feb26: 0.98, unit: 'mg/dL', target: '0.70-1.30', status: 'good', trend: '→' },
];

const supplements = [
  { name: 'Rosuvastatin', dose: '40mg', timing: 'Evening', cat: 'Rx', note: 'Statin — LDL lowering' },
  { name: 'Baby Aspirin', dose: '81mg', timing: 'Morning', cat: 'Cardiac', note: 'Antiplatelet — given Lp(a)' },
  { name: 'CoQ10', dose: '200mg', timing: 'Morning', cat: 'Cardiac', note: 'Mitochondrial support, statin offset' },
  { name: 'Fish Oil', dose: '2-4g EPA/DHA', timing: 'With meals', cat: 'Cardiac', note: 'Target 4g for Lp(a)' },
  { name: 'Boron', dose: '3-6mg', timing: 'Morning', cat: 'Hormones', note: 'Testosterone support' },
  { name: 'Multivitamin', dose: '1 daily', timing: 'Morning', cat: 'Foundation', note: 'Baseline micronutrients' },
  { name: 'Magnesium Glycinate', dose: '400mg', timing: 'Bedtime', cat: 'Recovery', note: 'Sleep + HRV support' },
  { name: 'Creatine', dose: '5g', timing: 'Post-workout', cat: 'Performance', note: 'Lean mass preservation' },
  { name: 'Whey Protein', dose: '30g', timing: 'Post-workout', cat: 'Nutrition', note: 'Within 45min of training' },
];

const supplementsRestart = [
  { name: 'Vitamin D3 + K2', dose: '5000 IU D3 / 100mcg K2', timing: 'Morning with fat', cat: 'Foundation', note: '⚠️ Dropped 84→58 ng/mL' },
];

const supplementsStopped = [
  { name: 'Ashwagandha', dose: '—', timing: '—', cat: '—', note: 'Caused DHEA-S spike 177→309' },
];

// ── Main App ──────────────────────────────────────────────────────
export default function HealthOS() {
  const [tab, setTab] = useState('dashboard');
  const [whoop, setWhoop] = useState(null);
  const [strava, setStrava] = useState(null);
  const [nutrition, setNutrition] = useState(null);
  const [hume, setHume] = useState(null);
  const [humeForm, setHumeForm] = useState({ weight: '', bf: '', lean: '' });
  const [bwFilter, setBwFilter] = useState('all');
  const [chatMessages, setChatMessages] = useState([
    { role: 'assistant', text: "Hey Richard 👋 I have your full health picture loaded — WHOOP, bloodwork, training, everything. What do you want to optimize today?" }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [loading, setLoading] = useState({ whoop: false, strava: false });
  const chatEndRef = useRef(null);
  const fileRef = useRef(null);

  // Fetch live data on mount
  useEffect(() => {
    fetchWhoop();
    fetchStrava();
    const savedHume = localStorage.getItem('hume_data');
    if (savedHume) setHume(JSON.parse(savedHume));
    const savedNutrition = localStorage.getItem('nutrition_data');
    if (savedNutrition) setNutrition(JSON.parse(savedNutrition));
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const fetchWhoop = async () => {
    setLoading(l => ({ ...l, whoop: true }));
    try {
      const res = await fetch('/api/whoop/data');
      if (res.ok) setWhoop(await res.json());
    } catch (e) {}
    setLoading(l => ({ ...l, whoop: false }));
  };

  const fetchStrava = async () => {
    setLoading(l => ({ ...l, strava: true }));
    try {
      const res = await fetch('/api/strava/data');
      if (res.ok) setStrava(await res.json());
    } catch (e) {}
    setLoading(l => ({ ...l, strava: false }));
  };

  const saveHume = () => {
    if (!humeForm.weight) return;
    const data = {
      weight: parseFloat(humeForm.weight),
      bf: parseFloat(humeForm.bf),
      lean: parseFloat(humeForm.lean),
      date: new Date().toISOString().split('T')[0],
    };
    setHume(data);
    localStorage.setItem('hume_data', JSON.stringify(data));
    setHumeForm({ weight: '', bf: '', lean: '' });
  };

  const handleCSV = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const text = await file.text();
    const res = await fetch('/api/nutrition/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ csvData: text }),
    });
    const data = await res.json();
    if (data.nutrition) {
      setNutrition(data.nutrition);
      localStorage.setItem('nutrition_data', JSON.stringify(data.nutrition));
    }
  };

  const sendChat = async () => {
    if (!chatInput.trim() || chatLoading) return;
    const msg = chatInput.trim();
    setChatInput('');
    setChatMessages(m => [...m, { role: 'user', text: msg }]);
    setChatLoading(true);
    try {
      const res = await fetch('/api/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg, context: { whoop: whoop, strava, nutrition, hume } }),
      });
      const data = await res.json();
      setChatMessages(m => [...m, { role: 'assistant', text: data.response || 'Sorry, something went wrong.' }]);
    } catch {
      setChatMessages(m => [...m, { role: 'assistant', text: 'Connection error. Try again.' }]);
    }
    setChatLoading(false);
  };

  const whoopColor = whoop?.today ? recoveryColor(whoop.today.recovery) : '#6b7280';

  // ── TABS ──────────────────────────────────────────────────────
  const tabs = [
    { id: 'dashboard', label: '⚡ Dashboard' },
    { id: 'training', label: '🏃 Training' },
    { id: 'bloodwork', label: '🩸 Labs' },
    { id: 'nutrition', label: '🥗 Nutrition' },
    { id: 'supplements', label: '💊 Supps' },
    { id: 'coach', label: '🤖 Coach' },
  ];

  return (
    <>
      <Head>
        <title>HealthOS — Richard Whalen</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="theme-color" content="#0a0f18" />
      </Head>

      <div className="min-h-screen" style={{ background: '#0a0f18', paddingBottom: '80px' }}>
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-3 border-b border-gray-800" style={{ background: '#0a0f18' }}>
          <div>
            <div className="font-bold text-lg" style={{ color: '#00ff88' }}>HealthOS</div>
            <div className="text-xs text-gray-500">Richard Whalen · 53</div>
          </div>
          <div className="flex items-center gap-2">
            {whoop?.connected
              ? <Badge color="green">WHOOP ✓</Badge>
              : <a href="/api/whoop/auth"><Badge color="gray">Connect WHOOP</Badge></a>}
            {strava?.connected
              ? <Badge color="blue">Strava ✓</Badge>
              : <a href="/api/strava/auth"><Badge color="gray">Connect Strava</Badge></a>}
          </div>
        </div>

        {/* Tab content */}
        <div className="max-w-2xl mx-auto px-4 pt-4">

          {/* ── DASHBOARD ── */}
          {tab === 'dashboard' && (
            <div className="space-y-4">

              {/* Lp(a) Alert */}
              <Card glow="red">
                <div className="flex items-start gap-3">
                  <span className="text-2xl">🚨</span>
                  <div>
                    <div className="font-semibold text-red-400">Lp(a) = 137 nmol/L — HIGH CARDIOVASCULAR RISK</div>
                    <div className="text-sm text-gray-400 mt-1">Genetic. Target LDL &lt;70 + ApoB &lt;70. Schedule Dr. Carda — discuss PCSK9 inhibitor.</div>
                  </div>
                </div>
              </Card>

              {/* WHOOP Recovery */}
              <Card>
                <div className="flex items-center justify-between mb-3">
                  <div className="font-semibold">Today's Recovery</div>
                  {whoop?.connected && <span className="text-xs text-gray-500">{new Date().toLocaleDateString()}</span>}
                </div>
                {whoop?.connected ? (
                  <>
                    <div className="flex justify-around mb-4">
                      <Ring value={whoop.today.recovery} color={whoopColor} label="Recovery" sub={recoveryLabel(whoop.today.recovery)} />
                      <Ring value={whoop.today.hrv} max={120} color="#60a5fa" label="HRV ms" />
                      <Ring value={whoop.today.rhr} max={90} color="#a78bfa" label="RHR bpm" />
                      <Ring value={whoop.today.sleepPerf} color="#fbbf24" label="Sleep %" />
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="rounded-lg p-2" style={{ background: '#1f2937' }}>
                        <div className="text-lg font-bold">{whoop.today.sleepHours}h</div>
                        <div className="text-xs text-gray-400">Sleep</div>
                      </div>
                      <div className="rounded-lg p-2" style={{ background: '#1f2937' }}>
                        <div className="text-lg font-bold">{whoop.today.strain}</div>
                        <div className="text-xs text-gray-400">Strain</div>
                      </div>
                      <div className="rounded-lg p-2" style={{ background: '#1f2937' }}>
                        <div className="text-lg font-bold" style={{ color: whoop.zone2Percent >= 45 ? '#00ff88' : '#fbbf24' }}>
                          {whoop.zone2Percent}%
                        </div>
                        <div className="text-xs text-gray-400">Zone 2</div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-6">
                    <div className="text-gray-500 mb-3">Connect WHOOP for live recovery data</div>
                    <a href="/api/whoop/auth" className="px-4 py-2 rounded-lg text-sm font-medium" style={{ background: '#00ff88', color: '#0a0f18' }}>
                      Connect WHOOP
                    </a>
                  </div>
                )}
              </Card>

              {/* Body Comp */}
              <Card>
                <div className="flex items-center justify-between mb-3">
                  <div className="font-semibold">Body Composition</div>
                  <span className="text-xs text-gray-500">Hume scale</span>
                </div>
                {hume ? (
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div>
                      <div className="text-2xl font-bold" style={{ color: '#00ff88' }}>{hume.weight}</div>
                      <div className="text-xs text-gray-400">lbs</div>
                      <div className="text-xs text-gray-600 mt-1">goal: 177</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold" style={{ color: hume.bf <= 18 ? '#00ff88' : '#fbbf24' }}>{hume.bf}%</div>
                      <div className="text-xs text-gray-400">body fat</div>
                      <div className="text-xs text-gray-600 mt-1">goal: &lt;18%</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-blue-400">{hume.lean}</div>
                      <div className="text-xs text-gray-400">lean lbs</div>
                      <div className="text-xs text-gray-600 mt-1">preserve</div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="text-sm text-gray-500 mb-2">Log your Hume reading</div>
                    <div className="flex gap-2">
                      <input className="flex-1 rounded-lg px-3 py-2 text-sm bg-gray-800 border border-gray-700 text-white" placeholder="Weight (lbs)" value={humeForm.weight} onChange={e => setHumeForm(f => ({ ...f, weight: e.target.value }))} />
                      <input className="flex-1 rounded-lg px-3 py-2 text-sm bg-gray-800 border border-gray-700 text-white" placeholder="BF%" value={humeForm.bf} onChange={e => setHumeForm(f => ({ ...f, bf: e.target.value }))} />
                      <input className="flex-1 rounded-lg px-3 py-2 text-sm bg-gray-800 border border-gray-700 text-white" placeholder="Lean lbs" value={humeForm.lean} onChange={e => setHumeForm(f => ({ ...f, lean: e.target.value }))} />
                    </div>
                    <button onClick={saveHume} className="w-full py-2 rounded-lg text-sm font-medium" style={{ background: '#00ff88', color: '#0a0f18' }}>Save</button>
                  </div>
                )}
                {hume && (
                  <button onClick={() => setHume(null)} className="mt-3 text-xs text-gray-600 hover:text-gray-400">Update reading</button>
                )}
              </Card>

              {/* Key lab flags */}
              <Card>
                <div className="font-semibold mb-3">Key Lab Flags</div>
                <div className="space-y-2">
                  {[
                    { label: 'Lp(a)', val: '137 nmol/L', status: 'critical', note: 'HIGH RISK — discuss PCSK9i' },
                    { label: 'Vitamin D', val: '58 ng/mL', status: 'watch', note: 'Restart D3 5000IU + K2 now' },
                    { label: 'Estradiol', val: '38 pg/mL', status: 'watch', note: 'Near top of range — retest 6-8wk' },
                    { label: 'ApoB', val: '78 mg/dL', status: 'watch', note: 'Target <70 given Lp(a)' },
                    { label: 'LDL', val: '77 mg/dL', status: 'watch', note: 'Target <70 — consider Ezetimibe' },
                    { label: 'Testosterone', val: '719 ng/dL', status: 'good', note: 'Best result yet ✓' },
                    { label: 'hsCRP', val: '0.4 mg/L', status: 'good', note: 'Excellent inflammatory control ✓' },
                    { label: 'HbA1c', val: '5.2%', status: 'good', note: 'Ideal metabolic control ✓' },
                  ].map(f => (
                    <div key={f.label} className="flex items-center gap-3 py-1">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: f.status === 'critical' ? '#f87171' : f.status === 'watch' ? '#fbbf24' : '#00ff88' }} />
                      <div className="flex-1 flex items-center justify-between">
                        <span className="text-sm font-medium">{f.label}</span>
                        <span className="text-sm text-gray-400">{f.val}</span>
                      </div>
                      <span className="text-xs text-gray-500 text-right w-40 hidden sm:block">{f.note}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          )}

          {/* ── TRAINING ── */}
          {tab === 'training' && (
            <div className="space-y-4">
              {strava?.connected ? (
                <>
                  <Card>
                    <div className="font-semibold mb-3">Year to Date</div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="rounded-lg p-3 text-center" style={{ background: '#1f2937' }}>
                        <div className="text-2xl font-bold text-blue-400">{strava.stats.ytdRunMiles}</div>
                        <div className="text-xs text-gray-400">miles run</div>
                        <div className="text-xs text-gray-600">{strava.stats.ytdRuns} runs</div>
                      </div>
                      <div className="rounded-lg p-3 text-center" style={{ background: '#1f2937' }}>
                        <div className="text-2xl font-bold" style={{ color: '#00ff88' }}>{strava.stats.ytdRideMiles}</div>
                        <div className="text-xs text-gray-400">miles ridden</div>
                        <div className="text-xs text-gray-600">{strava.stats.ytdRides} rides</div>
                      </div>
                    </div>
                  </Card>

                  {whoop?.connected && (
                    <Card>
                      <div className="font-semibold mb-3">Zone 2 Tracking</div>
                      <div className="flex items-center gap-4">
                        <div className="text-4xl font-bold" style={{ color: whoop.zone2Percent >= 45 ? '#00ff88' : '#fbbf24' }}>
                          {whoop.zone2Percent}%
                        </div>
                        <div>
                          <div className="text-sm text-gray-400">of recent training</div>
                          <div className="text-xs text-gray-600 mt-1">Target: 45%+ | Current: {whoop.zone2Percent >= 45 ? '✅ On target' : '⚠️ Below target'}</div>
                        </div>
                      </div>
                      <div className="mt-3 bg-gray-800 rounded-full h-2">
                        <div className="h-2 rounded-full transition-all" style={{ width: `${Math.min(whoop.zone2Percent, 100)}%`, background: whoop.zone2Percent >= 45 ? '#00ff88' : '#fbbf24' }} />
                      </div>
                    </Card>
                  )}

                  <Card>
                    <div className="font-semibold mb-3">Recent Activities</div>
                    <div className="space-y-3">
                      {(strava.recent || []).map((a, i) => (
                        <div key={i} className="flex items-center gap-3 py-2 border-b border-gray-800 last:border-0">
                          <div className="text-xl">{a.type === 'Run' ? '🏃' : a.type === 'Ride' || a.type === 'VirtualRide' ? '🚴' : '💪'}</div>
                          <div className="flex-1">
                            <div className="text-sm font-medium">{a.name}</div>
                            <div className="text-xs text-gray-500">{a.date}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium">{a.distance ? `${a.distance}mi` : `${a.duration}min`}</div>
                            {a.avgHR && <div className="text-xs text-gray-500">{a.avgHR} bpm avg</div>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                </>
              ) : (
                <Card>
                  <div className="text-center py-8">
                    <div className="text-4xl mb-3">🏃</div>
                    <div className="text-gray-400 mb-4">Connect Strava for automatic training data</div>
                    <a href="/api/strava/auth" className="px-6 py-2 rounded-lg text-sm font-medium" style={{ background: '#60a5fa', color: '#0a0f18' }}>
                      Connect Strava
                    </a>
                  </div>
                </Card>
              )}

              {/* WHOOP weekly trend */}
              {whoop?.history && (
                <Card>
                  <div className="font-semibold mb-3">7-Day Recovery Trend</div>
                  <div className="space-y-2">
                    {whoop.history.slice(0, 7).map((d, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <div className="text-xs text-gray-500 w-20">{d.date}</div>
                        <div className="flex-1 bg-gray-800 rounded-full h-2">
                          <div className="h-2 rounded-full" style={{ width: `${d.recovery}%`, background: recoveryColor(d.recovery) }} />
                        </div>
                        <div className="text-xs font-medium w-8 text-right" style={{ color: recoveryColor(d.recovery) }}>{d.recovery}%</div>
                        <div className="text-xs text-gray-500 w-16 text-right">HRV {d.hrv}ms</div>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>
          )}

          {/* ── BLOODWORK ── */}
          {tab === 'bloodwork' && (
            <div className="space-y-4">
              <div className="flex gap-2">
                {['all', 'critical', 'watch', 'good'].map(f => (
                  <button key={f} onClick={() => setBwFilter(f)}
                    className="px-3 py-1 rounded-full text-xs font-medium border transition-colors"
                    style={{
                      background: bwFilter === f ? (f === 'critical' ? '#7f1d1d' : f === 'watch' ? '#78350f' : f === 'good' ? '#14532d' : '#1f2937') : 'transparent',
                      borderColor: f === 'critical' ? '#f87171' : f === 'watch' ? '#fbbf24' : f === 'good' ? '#00ff88' : '#374151',
                      color: bwFilter === f ? '#fff' : '#9ca3af',
                    }}>
                    {f.charAt(0).toUpperCase() + f.slice(1)}
                  </button>
                ))}
              </div>

              <Card>
                <div className="text-xs text-gray-500 mb-3">Mar 2025 · Oct 2025 · Feb 2026 (latest)</div>
                <div className="space-y-0">
                  {bloodworkData.filter(b => bwFilter === 'all' || b.status === bwFilter).map((b, i) => (
                    <div key={b.name} className={`py-3 ${i > 0 ? 'border-t border-gray-800' : ''}`}>
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: b.status === 'critical' ? '#f87171' : b.status === 'watch' ? '#fbbf24' : '#00ff88' }} />
                        <span className="text-sm font-medium flex-1">{b.name}</span>
                        <span className="text-xs text-gray-500">{b.unit}</span>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <div className="flex-1 text-center rounded p-1" style={{ background: '#1f2937' }}>
                          <div className="text-xs text-gray-500">Mar 25</div>
                          <div className="text-sm font-medium">{b.mar25}</div>
                        </div>
                        <div className="flex-1 text-center rounded p-1" style={{ background: '#1f2937' }}>
                          <div className="text-xs text-gray-500">Oct 25</div>
                          <div className="text-sm font-medium">{b.oct25}</div>
                        </div>
                        <div className="flex-1 text-center rounded p-1 border" style={{ background: '#0f1f12', borderColor: b.status === 'critical' ? '#7f1d1d' : b.status === 'watch' ? '#78350f' : '#14532d' }}>
                          <div className="text-xs text-gray-500">Feb 26</div>
                          <div className="text-sm font-bold" style={{ color: b.status === 'critical' ? '#f87171' : b.status === 'watch' ? '#fbbf24' : '#00ff88' }}>{b.feb26}</div>
                        </div>
                        <div className="w-8 text-center flex items-center justify-center text-sm">{b.trend}</div>
                      </div>
                      <div className="text-xs text-gray-600 ml-4 mt-1">Target: {b.target}</div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          )}

          {/* ── NUTRITION ── */}
          {tab === 'nutrition' && (
            <div className="space-y-4">
              <Card>
                <div className="font-semibold mb-1">MyFitnessPal Import</div>
                <div className="text-xs text-gray-500 mb-3">Export diary from MFP app → tap the button below</div>
                <input ref={fileRef} type="file" accept=".csv" onChange={handleCSV} className="hidden" />
                <button onClick={() => fileRef.current?.click()} className="w-full py-3 rounded-lg text-sm font-semibold border border-dashed border-gray-600 text-gray-400 hover:border-green-500 hover:text-green-400 transition-colors">
                  📁 Upload MFP CSV export
                </button>
                <div className="mt-3 text-xs text-gray-600">
                  In MFP: More → Nutrition → Change Date Range → Export → share file here
                </div>
              </Card>

              {nutrition ? (
                <>
                  <Card>
                    <div className="font-semibold mb-1">Nutrition Summary</div>
                    <div className="text-xs text-gray-500 mb-3">{nutrition.dateRange} · {nutrition.days} days</div>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { label: 'Calories', val: nutrition.averages.calories, target: '1800-1900', unit: 'kcal', ok: nutrition.averages.calories >= 1700 && nutrition.averages.calories <= 2000 },
                        { label: 'Protein', val: nutrition.averages.protein, target: '160-175g', unit: 'g', ok: nutrition.averages.protein >= 155 },
                        { label: 'Carbs', val: nutrition.averages.carbs, target: '<200g', unit: 'g', ok: nutrition.averages.carbs <= 210 },
                        { label: 'Fat', val: nutrition.averages.fat, target: '50-70g', unit: 'g', ok: nutrition.averages.fat >= 45 && nutrition.averages.fat <= 80 },
                        { label: 'Fiber', val: nutrition.averages.fiber, target: '>30g', unit: 'g', ok: nutrition.averages.fiber >= 28 },
                        { label: 'Sodium', val: nutrition.averages.sodium, target: '<2300mg', unit: 'mg', ok: nutrition.averages.sodium <= 2400 },
                      ].map(m => (
                        <div key={m.label} className="rounded-lg p-3" style={{ background: '#1f2937' }}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs text-gray-400">{m.label}</span>
                            <span className="text-xs" style={{ color: m.ok ? '#00ff88' : '#fbbf24' }}>{m.ok ? '✓' : '⚠'}</span>
                          </div>
                          <div className="text-xl font-bold" style={{ color: m.ok ? '#00ff88' : '#fbbf24' }}>{m.val}{m.unit}</div>
                          <div className="text-xs text-gray-600 mt-1">target: {m.target}</div>
                        </div>
                      ))}
                    </div>
                  </Card>
                </>
              ) : (
                <Card>
                  <div className="text-center py-6 text-gray-500">
                    <div className="text-3xl mb-2">🥗</div>
                    <div>No nutrition data yet</div>
                    <div className="text-xs mt-1">Upload your MFP CSV above</div>
                  </div>
                </Card>
              )}

              {/* Targets */}
              <Card>
                <div className="font-semibold mb-3">Your Nutrition Targets</div>
                <div className="space-y-2 text-sm">
                  {[
                    { label: 'Daily calories', val: '1,800–1,900 kcal', note: '300-400 kcal deficit for fat loss' },
                    { label: 'Protein', val: '160–175g', note: '1.1g per lb lean mass' },
                    { label: 'EPA/DHA omega-3', val: '3–4g', note: 'Critical for Lp(a) — maximize fish oil' },
                    { label: 'Carb timing', val: '60–80% pre/post workout', note: 'Reduce carbs after 7pm' },
                    { label: 'Meal frequency', val: '4 meals at 40-45g protein each', note: 'Maximize muscle protein synthesis' },
                  ].map(t => (
                    <div key={t.label} className="flex gap-3 py-2 border-b border-gray-800 last:border-0">
                      <div className="flex-1">
                        <div className="font-medium">{t.label}</div>
                        <div className="text-xs text-gray-500 mt-0.5">{t.note}</div>
                      </div>
                      <div className="text-right font-semibold" style={{ color: '#00ff88' }}>{t.val}</div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          )}

          {/* ── SUPPLEMENTS ── */}
          {tab === 'supplements' && (
            <div className="space-y-4">
              <Card>
                <div className="font-semibold mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-400 inline-block" /> Active Stack
                </div>
                <div className="space-y-3">
                  {supplements.map(s => (
                    <div key={s.name} className="flex items-start gap-3 py-2 border-b border-gray-800 last:border-0">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold">{s.name}</span>
                          <Badge color="gray">{s.cat}</Badge>
                        </div>
                        <div className="text-xs text-gray-500 mt-0.5">{s.note}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium" style={{ color: '#00ff88' }}>{s.dose}</div>
                        <div className="text-xs text-gray-500">{s.timing}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card glow="red">
                <div className="font-semibold mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-yellow-400 inline-block" /> ⚠️ Restart Immediately
                </div>
                {supplementsRestart.map(s => (
                  <div key={s.name} className="flex items-start gap-3">
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-yellow-300">{s.name}</div>
                      <div className="text-xs text-gray-400 mt-0.5">{s.note}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-yellow-300">{s.dose}</div>
                      <div className="text-xs text-gray-500">{s.timing}</div>
                    </div>
                  </div>
                ))}
              </Card>

              <Card>
                <div className="font-semibold mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-400 inline-block" /> Stopped
                </div>
                {supplementsStopped.map(s => (
                  <div key={s.name} className="flex items-start gap-3">
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-red-400 line-through">{s.name}</div>
                      <div className="text-xs text-gray-500 mt-0.5">{s.note}</div>
                    </div>
                  </div>
                ))}
              </Card>

              <Card>
                <div className="font-semibold mb-3">💊 Consider Adding</div>
                <div className="space-y-2">
                  {[
                    { name: 'Ezetimibe 10mg', reason: 'Drops LDL 15-20% with minimal side effects — discuss with Dr. Carda' },
                    { name: 'Vascepa (Rx EPA)', reason: 'REDUCE-IT trial: 25% CV event reduction. Need Rx for prescription-grade EPA' },
                    { name: 'L-Theanine 200mg', reason: 'Pair with Magnesium Glycinate at bedtime — enhances sleep quality' },
                  ].map(s => (
                    <div key={s.name} className="rounded-lg p-3" style={{ background: '#1f2937' }}>
                      <div className="text-sm font-semibold text-blue-400">{s.name}</div>
                      <div className="text-xs text-gray-400 mt-1">{s.reason}</div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          )}

          {/* ── COACH ── */}
          {tab === 'coach' && (
            <div className="flex flex-col" style={{ height: 'calc(100vh - 200px)' }}>
              {/* Quick prompts */}
              <div className="flex gap-2 overflow-x-auto pb-2 mb-3 no-scrollbar">
                {[
                  "How should I train today?",
                  "Analyze my Lp(a) risk",
                  "Am I hitting protein targets?",
                  "Optimize my sleep",
                  "Zone 2 strategy",
                  "Supplement timing",
                ].map(p => (
                  <button key={p} onClick={() => { setChatInput(p); }}
                    className="flex-shrink-0 px-3 py-1.5 rounded-full text-xs border border-gray-700 text-gray-400 hover:border-green-500 hover:text-green-400 transition-colors whitespace-nowrap">
                    {p}
                  </button>
                ))}
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto space-y-3 mb-3">
                {chatMessages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className="max-w-xs rounded-2xl px-4 py-3 text-sm" style={{
                      background: m.role === 'user' ? '#00ff88' : '#1f2937',
                      color: m.role === 'user' ? '#0a0f18' : '#f9fafb',
                      borderRadius: m.role === 'user' ? '20px 20px 4px 20px' : '20px 20px 20px 4px',
                    }}>
                      {m.text}
                    </div>
                  </div>
                ))}
                {chatLoading && (
                  <div className="flex justify-start">
                    <div className="rounded-2xl px-4 py-3 text-sm" style={{ background: '#1f2937' }}>
                      <span className="animate-pulse">Thinking...</span>
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Input */}
              <div className="flex gap-2">
                <input
                  className="flex-1 rounded-xl px-4 py-3 text-sm bg-gray-800 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:border-green-500"
                  placeholder="Ask your coach..."
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && sendChat()}
                />
                <button onClick={sendChat} disabled={chatLoading}
                  className="w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg disabled:opacity-50"
                  style={{ background: '#00ff88', color: '#0a0f18' }}>
                  →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Nav */}
        <div className="fixed bottom-0 left-0 right-0 border-t border-gray-800 flex" style={{ background: '#0a0f18' }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className="flex-1 py-3 text-xs transition-colors"
              style={{ color: tab === t.id ? '#00ff88' : '#6b7280', borderTop: tab === t.id ? '2px solid #00ff88' : '2px solid transparent' }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
