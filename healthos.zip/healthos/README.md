# HealthOS — Richard Whalen

Personal health optimization dashboard with live WHOOP + Strava integration and Claude AI coaching.

## Stack
- Next.js 14 (React)
- WHOOP API v2 (live recovery, HRV, sleep, strain)
- Strava API (runs, rides, training stats)
- Anthropic Claude claude-sonnet-4-20250514 (AI coaching)
- MyFitnessPal CSV upload (nutrition)
- Hume scale manual entry (body comp)

---

## Deployment Guide (Step by Step)

### Step 1 — Push to GitHub
1. Go to github.com → New repository → name it `healthos` → Create
2. Open Terminal (Mac) or Command Prompt (Windows)
3. Run these commands:
```
cd path/to/this/folder
git init
git add .
git commit -m "Initial HealthOS"
git remote add origin https://github.com/Unclewichie/healthos.git
git push -u origin main
```

### Step 2 — Get your API keys

**WHOOP:**
1. Go to developer.whoop.com → sign in with your WHOOP account
2. Create App → name it "HealthOS"
3. Set redirect URI to: https://YOUR-APP.vercel.app/api/whoop/callback
4. Copy Client ID + Client Secret

**Strava:**
1. Go to strava.com/settings/api → Create App
2. Set Authorization Callback Domain to: YOUR-APP.vercel.app
3. Copy Client ID + Client Secret

**Anthropic:**
1. Go to console.anthropic.com → API Keys → Create Key
2. Copy the key (starts with sk-ant-)

### Step 3 — Deploy to Vercel
1. Go to vercel.com → sign up with GitHub
2. New Project → Import your `healthos` repo
3. Add Environment Variables (Settings → Environment Variables):
   - ANTHROPIC_API_KEY
   - WHOOP_CLIENT_ID
   - WHOOP_CLIENT_SECRET
   - WHOOP_REDIRECT_URI (use your actual Vercel URL)
   - STRAVA_CLIENT_ID
   - STRAVA_CLIENT_SECRET
   - STRAVA_REDIRECT_URI (use your actual Vercel URL)
4. Deploy

### Step 4 — Add to iPhone
1. Open your Vercel URL in Safari
2. Tap Share → Add to Home Screen
3. Done — full app, no browser chrome

---

## Features
- ⚡ Live WHOOP recovery, HRV, sleep, strain
- 🏃 Live Strava training data, Zone 2 tracking
- 🩸 3-panel bloodwork comparison with trend arrows
- 🥗 MFP CSV upload with macro analysis
- 💊 Full supplement stack with restart alerts
- 🤖 Claude AI coach with your full health context
- 📱 iPhone PWA — works offline after first load
